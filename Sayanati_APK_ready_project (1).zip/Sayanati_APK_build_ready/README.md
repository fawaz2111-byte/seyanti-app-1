# صيانتي — نسخة APK جاهزة للبناء
هذه نسخة Android Studio مبسطة من تطبيق صيانتي.
ملاحظة: لا يمكن إنشاء APK ثنائي فعلي داخل هذه البيئة لأن Android SDK/Gradle build environment غير متاح.
افتح المشروع في Android Studio واختر Build > Generate App Bundle / APK > Generate APK.

package com.sayanati.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SayanatiApp() }
    }
}

data class Service(val name:String, val date:String, val km:String, val cost:String)
data class Car(val name:String, val year:String, val engine:String)

@Composable
fun SayanatiApp() {
    var tab by remember { mutableIntStateOf(0) }
    var services by remember { mutableStateOf(listOf(
        Service("تغيير زيت المحرك", "24/09/2026", "—", "—"),
        Service("فحص عام", "—", "—", "—")
    )) }
    val car = Car("Mitsubishi Lancer", "2008", "2.0 أوتوماتيك")

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("الرئيسية","الصيانة","التشخيص","المصاريف").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("🏠","🔧","🔎","💰")[i]) },
                        label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Text("صيانتي", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            when(tab) {
                0 -> Home(car, services)
                1 -> Maintenance(services) { services = services + it }
                2 -> Diagnosis()
                3 -> Expenses(services)
            }
        }
    }
}

@Composable
fun Home(car:Car, services:List<Service>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("${car.name} ${car.year}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("المحرك: ${car.engine}")
            Spacer(Modifier.height(12.dp))
            Text("آخر عمليات الصيانة: ${services.size}")
            Text("تقدر تسجل الصيانة وتراجع التشخيص والمصاريف من الأسفل.")
        }
    }
}

@Composable
fun Maintenance(services:List<Service>, add:(Service)->Unit) {
    var show by remember { mutableStateOf(false) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("سجل الصيانة", style = MaterialTheme.typography.titleLarge)
            Button({ show = true }) { Text("إضافة") }
        }
        LazyColumn {
            items(services.reversed()) { s ->
                ListItem(
                    headlineContent = { Text(s.name) },
                    supportingContent = { Text("التاريخ: ${s.date} • الكيلومترات: ${s.km} • التكلفة: ${s.cost}") }
                )
                HorizontalDivider()
            }
        }
    }
    if (show) {
        var name by remember { mutableStateOf("") }
        var cost by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("إضافة صيانة") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label={Text("نوع الصيانة")})
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(cost, { cost = it }, label={Text("التكلفة")})
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) add(Service(name, "24/09/2026", "—", if(cost.isBlank()) "—" else cost))
                    show = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton({show=false}) { Text("إلغاء") } }
        )
    }
}

@Composable
fun Diagnosis() {
    Column {
        Text("وش فيها السيارة؟", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("اختر العرض الأقرب، وبعدها افحص الأسباب من الأبسط للأصعب.")
        Spacer(Modifier.height(12.dp))
        listOf(
            "تفتفة أو تقطيع عند الدعس",
            "ونة تظهر مع الدعس",
            "رجّة على الوقوف",
            "صعوبة تشغيل",
            "حرارة مرتفعة"
        ).forEach {
            OutlinedButton({}) { Text(it) }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
fun Expenses(services:List<Service>) {
    Text("المصاريف", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text("عدد عمليات الصيانة المسجلة: ${services.size}")
    Spacer(Modifier.height(8.dp))
    Text("الإصدار الحالي تجريبي؛ سجل المبالغ لكل عملية لمتابعة إجمالي المصروف.")
}
